
public class Gold extends GameItem {
String game_items;
public String return_item()
{
	game_items="G";
	return game_items;
}
}
