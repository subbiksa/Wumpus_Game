
public class Wumpus extends GameItem {
	String game_Item;
	public String return_gameItem()
	{
		game_Item="W";
		return game_Item;
	}

}
