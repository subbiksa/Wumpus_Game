
public class Pit extends GameItem  {
	String game_items;
	public String return_items()
	{
		game_items="P";
	return game_items;	
	}

}
